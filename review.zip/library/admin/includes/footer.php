   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2018 ANITS Online Library Management System |<a href="http://www.anits.edu.in" target="_blank"  > Designed by : Batch No: 9</a> 
                </div>

            </div>
        </div>
    </section>